/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab5;

import java.io.Serializable;

/**
 *
 * @author buimi
 */
public class Staff implements Serializable {

    public String fullname;
    public double salary;
}
